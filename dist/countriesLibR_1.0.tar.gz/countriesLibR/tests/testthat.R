library(testthat)
library(countriesLibR)

test_check("countriesLibR")
